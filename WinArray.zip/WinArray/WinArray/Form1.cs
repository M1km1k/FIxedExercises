﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinArray
{
    public partial class Form1 : Form
    {
        private const int NumberOfNumbers = 10;
        private int[] numbers = new int[NumberOfNumbers];
        private int currentNumberIndex = 0;

        public Form1()
        {
            InitializeComponent();
            numberListView.View = View.Details;
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            if (currentNumberIndex < NumberOfNumbers)
            {
                MessageBox.Show("Please enter 10 numbers first.", "Insufficient Data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            double mean = ComputeMean(numbers);
            double median = ComputeMedian(numbers);
            int mode = ComputeMode(numbers);

            meanLabel.Text = $"Mean: {mean}";
            medianLabel.Text = $"Median: {median}";
            modeLabel.Text = $"Mode: {mode}";

        }

        private void addButton_Click(object sender, EventArgs e)
        {
            if (currentNumberIndex < NumberOfNumbers)
            {
                if (int.TryParse(numberTextBox.Text, out int number))
                {
                    numbers[currentNumberIndex] = number;
                    numberTextBox.Clear();
                    currentNumberIndex++;
                    numberListBox.Items.Add(number);
                  
                    ListViewItem item = new ListViewItem(number.ToString());
                    numberListView.Items.Add(item);


                    calculateButton.Enabled = currentNumberIndex >= 2;
                }
                else
                {
                    MessageBox.Show("Please enter a valid number.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("You have entered the maximum number of values.", "Maximum Reached", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private double ComputeMean(int[] nums)
        {
            return nums.Sum() / (double)nums.Length;
        }

        private double ComputeMedian(int[] nums)
        {
            Array.Sort(nums);
            int middle = nums.Length / 2;
            double median = (nums.Length % 2 == 0) ? ((double)nums[middle - 1] + nums[middle]) / 2 : nums[middle];
            return median;
        }

        private int ComputeMode(int[] nums)
        {
            var groups = nums.GroupBy(x => x);
            var maxCount = groups.Max(g => g.Count());
            return groups.First(g => g.Count() == maxCount).Key;
        }


    }
}
