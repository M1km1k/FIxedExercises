﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace BookMonitoringSystem
{
    public partial class frmBook : Form
    {

        OleDbConnection con;

        public frmBook()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\Baron\\Project\\BookMonitoringSystem.mdb");

        }

        private void loadDatagrid()
        {

            con.Open();

            OleDbCommand com = new OleDbCommand("Select * from Book", con);
            com.ExecuteNonQuery();

            OleDbDataAdapter adap = new OleDbDataAdapter(com); 
            DataTable tab = new DataTable();

            adap.Fill(tab);
            dgvBookRecords.DataSource = tab;

            con.Close();


        }

        private void frmBook_Load(object sender, EventArgs e)
        {

            loadDatagrid();

        }


        private void btnSave_Click(object sender, EventArgs e)
        {

            try
            {
                con.Open();

                // Assuming bookID is an auto-increment primary key in your database
                // Using parameterized query to prevent SQL injection
                OleDbCommand com = new OleDbCommand("INSERT INTO book (title, author) VALUES (?, ?)", con);
                com.Parameters.AddWithValue("@title", txtTitle.Text);
                com.Parameters.AddWithValue("@author", txtAuthor.Text);
                com.ExecuteNonQuery();

                MessageBox.Show("Successfully SAVED!", "New Record", MessageBoxButtons.OK, MessageBoxIcon.Information);

                con.Close();
                loadDatagrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

            con.Open();

            OleDbCommand com = new OleDbCommand("Select * from Book where title like '%" + txtSearch.Text + "%'", con);
            com.ExecuteNonQuery();

            OleDbDataAdapter adap = new OleDbDataAdapter(com);
            DataTable tab = new DataTable();

            adap.Fill(tab);
            dgvBookRecords.DataSource = tab;

            con.Close();

        }

        private void dgvBookRecords_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            txtBookID.Text = dataGridView1.Rows[e.RowIndex].Cells["bookID"].Value.ToString();
            txtTitle.Text = dataGridView1.Rows[e.RowIndex].Cells["title"].Value.ToString();
            txtAuthor.Text = dataGridView1.Rows[e.RowIndex].Cells["author"].Value.ToString();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            try
            {
                con.Open();

                int no = int.Parse(txtBookID.Text);

                // Using parameterized query to prevent SQL injection
                OleDbCommand com = new OleDbCommand("UPDATE book SET title = ?, Author = ? WHERE bookID = ?", con);
                com.Parameters.AddWithValue("@title", txtTitle.Text);
                com.Parameters.AddWithValue("@author", txtAuthor.Text);
                com.Parameters.AddWithValue("@bookID", no);
                com.ExecuteNonQuery();

                MessageBox.Show("Successfully UPDATED!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);

                con.Close();
                loadDatagrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Assuming con is an instance of OleDbConnection
            con.Open();
            int num = int.Parse(txtBookID.Text);

            DialogResult dr = MessageBox.Show("Are you sure you want to delete this?", "Confirm Deletion",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dr == DialogResult.Yes)
            {
                // Assuming con is an instance of OleDbConnection
                OleDbCommand com = new OleDbCommand("DELETE FROM book WHERE bookID = " + num, con);
                com.ExecuteNonQuery();

                MessageBox.Show("Successfully DELETED", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("CANCELLED!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            con.Close();
            loadDatagrid(); // Make sure loadDatagrid() method exists and reloads your data grid
        }

  



    }
}
