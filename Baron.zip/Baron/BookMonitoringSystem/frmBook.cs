﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace BookMonitoringSystem
{
    public partial class frmBook : Form
    {

        OleDbConnection con;

        public frmBook()
        {
            InitializeComponent();
            con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\Baron\\Project\\BookMonitoringSystem.mdb");

        }

        private void loadDatagrid()
        {

            con.Open();

            OleDbCommand com = new OleDbCommand("Select * from Book", con);
            com.ExecuteNonQuery();

            OleDbDataAdapter adap = new OleDbDataAdapter(com); 
            DataTable tab = new DataTable();

            adap.Fill(tab);
            dgvBookRecords.DataSource = tab;

            con.Close();


        }

        private void frmBook_Load(object sender, EventArgs e)
        {

            loadDatagrid();

        }


        private void btnSave_Click(object sender, EventArgs e)
        {

            con.Open();

            OleDbCommand com = new OleDbCommand("Insert into book values ('" + txtTitle.Text + "' , '" + txtAuthor.Text + "')",con);
            com.ExecuteNonQuery();

            MessageBox.Show("Successfully SAVED!", "New Record", MessageBoxButtons.OK, MessageBoxIcon.Information);

            con.Close();
            loadDatagrid();

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

            con.Open();

            OleDbCommand com = new OleDbCommand("Select * from Book where title like '%" + txtSearch.Text + "%'", con);
            com.ExecuteNonQuery();

            OleDbDataAdapter adap = new OleDbDataAdapter(com);
            DataTable tab = new DataTable();

            adap.Fill(tab);
            dgvBookRecords.DataSource = tab;

            con.Close();

        }
    }
}
